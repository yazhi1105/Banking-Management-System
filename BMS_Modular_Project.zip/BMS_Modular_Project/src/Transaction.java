
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private final String type;
    private final BigDecimal amount;
    private final BigDecimal balanceAfter;
    private final String relatedAccount;
    private final LocalDateTime time;

    public Transaction(
            String type,
            BigDecimal amount,
            BigDecimal balanceAfter) {
        this(type, amount, balanceAfter, "");
    }

    public Transaction(
            String type,
            BigDecimal amount,
            BigDecimal balanceAfter,
            String relatedAccount) {
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.relatedAccount = relatedAccount == null ? "" : relatedAccount;
        this.time = LocalDateTime.now();
    }

    public String toJson() {
        String formattedTime = time.format(
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        );

        return "{"
            + "\"type\":\"" + escape(type) + "\","
            + "\"amount\":" + amount.toPlainString() + ","
            + "\"balanceAfter\":" + balanceAfter.toPlainString() + ","
            + "\"relatedAccount\":\"" + escape(relatedAccount) + "\","
            + "\"time\":\"" + escape(formattedTime) + "\""
            + "}";
    }

    private String escape(String value) {
        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t");
    }
}
