
import java.math.BigDecimal;
import java.math.RoundingMode;

public class BankAccount {
    private final String name;
    private final String accountNumber;
    private BigDecimal balance = BigDecimal.ZERO.setScale(2);

    public BankAccount(String name, String accountNumber) {
        this.name = name;
        this.accountNumber = accountNumber;
    }

    public synchronized void deposit(BigDecimal amount) {
        validate(amount);
        balance = balance.add(amount);
    }

    public synchronized void withdraw(BigDecimal amount) {
        validate(amount);

        if (amount.compareTo(balance) > 0) {
            throw new IllegalArgumentException("Insufficient balance!");
        }

        balance = balance.subtract(amount);
    }

    private void validate(BigDecimal amount) {
        if (amount == null
                || amount.compareTo(BigDecimal.ZERO) <= 0
                || amount.scale() > 2) {
            throw new IllegalArgumentException(
                "Enter a positive amount with up to 2 decimal places."
            );
        }
    }

    public synchronized BigDecimal getBalance() {
        return balance.setScale(2, RoundingMode.HALF_UP);
    }

    public String getName() {
        return name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
}
