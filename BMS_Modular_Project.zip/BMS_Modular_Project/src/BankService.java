
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BankService {
    private BankAccount account;

    private final Map<String, BankAccount> accounts =
        new LinkedHashMap<>();

    private final Map<String, List<Transaction>> transactionHistories =
        new LinkedHashMap<>();

    public synchronized BankAccount createAccount(
            String name,
            String accountNumber) {
        if (account != null) {
            throw new IllegalArgumentException(
                "Your main account already exists."
            );
        }

        String cleanName = clean(name);
        String cleanNumber = clean(accountNumber);

        validateAccountDetails(cleanName, cleanNumber);

        account = new BankAccount(cleanName, cleanNumber);
        accounts.put(cleanNumber, account);
        transactionHistories.put(cleanNumber, new ArrayList<>());

        return account;
    }

    public synchronized BankAccount createRecipientAccount(
            String name,
            String accountNumber) {
        requireMainAccount();

        String cleanName = clean(name);
        String cleanNumber = clean(accountNumber);

        validateAccountDetails(cleanName, cleanNumber);

        if (accounts.containsKey(cleanNumber)) {
            throw new IllegalArgumentException(
                "That account number is already registered."
            );
        }

        BankAccount recipient = new BankAccount(
            cleanName,
            cleanNumber
        );

        accounts.put(cleanNumber, recipient);
        transactionHistories.put(cleanNumber, new ArrayList<>());

        return recipient;
    }

    public synchronized void deposit(BigDecimal amount) {
        requireMainAccount();

        account.deposit(amount);

        transactionHistories.get(account.getAccountNumber()).add(
            new Transaction(
                "DEPOSIT",
                amount,
                account.getBalance()
            )
        );
    }

    public synchronized void withdraw(BigDecimal amount) {
        requireMainAccount();

        account.withdraw(amount);

        transactionHistories.get(account.getAccountNumber()).add(
            new Transaction(
                "WITHDRAWAL",
                amount,
                account.getBalance()
            )
        );
    }

    public synchronized void transfer(
            String recipientNumber,
            BigDecimal amount) {
        requireMainAccount();

        String cleanRecipientNumber = clean(recipientNumber);

        if (cleanRecipientNumber.isEmpty()) {
            throw new IllegalArgumentException(
                "Enter the recipient account number."
            );
        }

        BankAccount recipient = accounts.get(cleanRecipientNumber);

        if (recipient == null) {
            throw new IllegalArgumentException(
                "Recipient account not found. Register it first."
            );
        }

        if (recipient.getAccountNumber().equals(
                account.getAccountNumber())) {
            throw new IllegalArgumentException(
                "You cannot transfer money to your own account."
            );
        }

        // Validate and check the sender balance before changing either
        // account. The service lock serializes all banking operations.
        if (amount == null
                || amount.compareTo(BigDecimal.ZERO) <= 0
                || amount.scale() > 2) {
            throw new IllegalArgumentException(
                "Enter a positive amount with up to 2 decimal places."
            );
        }

        if (amount.compareTo(account.getBalance()) > 0) {
            throw new IllegalArgumentException("Insufficient balance!");
        }

        account.withdraw(amount);
        recipient.deposit(amount);

        transactionHistories.get(account.getAccountNumber()).add(
            new Transaction(
                "TRANSFER_OUT",
                amount,
                account.getBalance(),
                recipient.getAccountNumber()
            )
        );

        transactionHistories.get(recipient.getAccountNumber()).add(
            new Transaction(
                "TRANSFER_IN",
                amount,
                recipient.getBalance(),
                account.getAccountNumber()
            )
        );
    }

    public synchronized BankAccount getAccount() {
        requireMainAccount();
        return account;
    }

    public synchronized List<Transaction> getTransactions() {
        requireMainAccount();

        return new ArrayList<>(
            transactionHistories.get(account.getAccountNumber())
        );
    }

    public synchronized List<BankAccount> getRecipients() {
        requireMainAccount();

        List<BankAccount> recipients = new ArrayList<>();

        for (BankAccount current : accounts.values()) {
            if (!current.getAccountNumber().equals(
                    account.getAccountNumber())) {
                recipients.add(current);
            }
        }

        return recipients;
    }

    private void validateAccountDetails(
            String name,
            String accountNumber) {
        if (name.isEmpty() || accountNumber.isEmpty()) {
            throw new IllegalArgumentException(
                "Name and account number are required."
            );
        }

        if (accountNumber.length() > 30) {
            throw new IllegalArgumentException(
                "Account number must be 30 characters or fewer."
            );
        }
    }

    private String clean(String value) {
        return value == null ? "" : value.trim();
    }

    private void requireMainAccount() {
        if (account == null) {
            throw new IllegalArgumentException(
                "Please create your main account first."
            );
        }
    }
}
