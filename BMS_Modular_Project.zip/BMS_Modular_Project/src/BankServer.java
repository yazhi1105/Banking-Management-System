
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BankServer {
    private static final BankService bank = new BankService();
    private static final int PORT = 8080;

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(
            new InetSocketAddress("127.0.0.1", PORT), 0
        );

        server.createContext("/", BankServer::handleRequest);
        server.setExecutor(null);
        server.start();

        System.out.println("Vaultly is running at http://127.0.0.1:" + PORT);
        System.out.println("Keep this terminal open while using Vaultly.");
    }

    private static void handleRequest(HttpExchange exchange)
            throws IOException {
        String path = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod();

        try {
            if (method.equals("GET") && path.equals("/")) {
                serveIndex(exchange);
                return;
            }

            if (method.equals("GET") && path.equals("/api/details")) {
                sendJson(exchange, 200, detailsJson("Ready."));
                return;
            }

            if (method.equals("GET") && path.equals("/api/transactions")) {
                sendJson(exchange, 200, transactionsJson());
                return;
            }

            if (method.equals("GET") && path.equals("/api/recipients")) {
                sendJson(exchange, 200, recipientsJson());
                return;
            }

            if (!method.equals("POST")) {
                sendJson(exchange, 405,
                    "{\"ok\":false,\"message\":\"Method not allowed.\"}");
                return;
            }

            Map<String, String> form = readForm(exchange);

            switch (path) {
                case "/api/account" -> {
                    bank.createAccount(
                        form.get("name"),
                        form.get("accountNumber")
                    );
                    sendJson(exchange, 200, detailsJson(
                        "Main account created successfully."
                    ));
                }

                case "/api/recipient" -> {
                    bank.createRecipientAccount(
                        form.get("name"),
                        form.get("accountNumber")
                    );
                    sendJson(exchange, 200, detailsJson(
                        "Recipient account registered successfully."
                    ));
                }

                case "/api/deposit" -> {
                    bank.deposit(parseAmount(form));
                    sendJson(exchange, 200, detailsJson(
                        "Deposit completed successfully."
                    ));
                }

                case "/api/withdraw" -> {
                    bank.withdraw(parseAmount(form));
                    sendJson(exchange, 200, detailsJson(
                        "Withdrawal completed successfully."
                    ));
                }

                case "/api/transfer" -> {
                    bank.transfer(
                        form.get("recipientAccount"),
                        parseAmount(form)
                    );
                    sendJson(exchange, 200, detailsJson(
                        "Transfer completed successfully."
                    ));
                }

                default -> sendJson(exchange, 404,
                    "{\"ok\":false,\"message\":\"Endpoint not found.\"}");
            }
        } catch (IllegalArgumentException e) {
            sendJson(exchange, 400, errorJson(e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            sendJson(exchange, 500,
                errorJson("A server error occurred. Please try again."));
        } finally {
            exchange.close();
        }
    }

    private static void serveIndex(HttpExchange exchange)
            throws IOException {
        Path file = Path.of("web", "index.html");

        if (!Files.exists(file)) {
            send(exchange, 500, "text/plain; charset=UTF-8",
                "Cannot find web/index.html. Run the server from the project root.");
            return;
        }

        send(exchange, 200, "text/html; charset=UTF-8",
            Files.readString(file, StandardCharsets.UTF_8));
    }

    private static BigDecimal parseAmount(Map<String, String> form) {
        String value = form.get("amount");

        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Enter an amount.");
        }

        try {
            BigDecimal amount = new BigDecimal(value.trim());

            if (amount.scale() > 2) {
                throw new IllegalArgumentException(
                    "Use no more than 2 decimal places."
                );
            }

            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException(
                    "Amount must be greater than zero."
                );
            }

            return amount;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                "Enter a valid numeric amount."
            );
        }
    }

    private static Map<String, String> readForm(HttpExchange exchange)
            throws IOException {
        String body = new String(
            exchange.getRequestBody().readAllBytes(),
            StandardCharsets.UTF_8
        );

        Map<String, String> values = new LinkedHashMap<>();

        if (body.isBlank()) {
            return values;
        }

        for (String pair : body.split("&")) {
            String[] parts = pair.split("=", 2);

            String key = URLDecoder.decode(
                parts[0], StandardCharsets.UTF_8
            );

            String value = parts.length > 1
                ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8)
                : "";

            values.put(key, value);
        }

        return values;
    }

    private static String detailsJson(String message) {
        try {
            BankAccount account = bank.getAccount();

            return "{"
                + "\"ok\":true,"
                + "\"message\":\"" + escape(message) + "\","
                + "\"accountExists\":true,"
                + "\"name\":\"" + escape(account.getName()) + "\","
                + "\"accountNumber\":\""
                    + escape(account.getAccountNumber()) + "\","
                + "\"balance\":" + account.getBalance().toPlainString()
                + "}";
        } catch (IllegalArgumentException e) {
            return "{"
                + "\"ok\":true,"
                + "\"message\":\"" + escape(message) + "\","
                + "\"accountExists\":false,"
                + "\"name\":\"\","
                + "\"accountNumber\":\"\","
                + "\"balance\":0.00"
                + "}";
        }
    }

    private static String transactionsJson() {
        List<Transaction> transactions = bank.getTransactions();
        StringBuilder json = new StringBuilder("[");
        boolean first = true;

        for (Transaction transaction : transactions) {
            if (!first) {
                json.append(",");
            }
            json.append(transaction.toJson());
            first = false;
        }

        return json.append("]").toString();
    }

    private static String recipientsJson() {
        List<BankAccount> recipients = bank.getRecipients();
        StringBuilder json = new StringBuilder("{\"ok\":true,\"recipients\":[");
        boolean first = true;

        for (BankAccount recipient : recipients) {
            if (!first) {
                json.append(",");
            }

            json.append("{")
                .append("\"name\":\"")
                .append(escape(recipient.getName()))
                .append("\",\"accountNumber\":\"")
                .append(escape(recipient.getAccountNumber()))
                .append("\"}");

            first = false;
        }

        return json.append("]}").toString();
    }

    private static String errorJson(String message) {
        return "{\"ok\":false,\"message\":\""
            + escape(message == null ? "Request failed." : message)
            + "\"}";
    }

    private static String escape(String value) {
        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t");
    }

    private static void sendJson(
            HttpExchange exchange,
            int status,
            String json) throws IOException {
        send(exchange, status, "application/json; charset=UTF-8", json);
    }

    private static void send(
            HttpExchange exchange,
            int status,
            String contentType,
            String response) throws IOException {
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);

        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(status, bytes.length);

        exchange.getResponseBody().write(bytes);
    }
}
