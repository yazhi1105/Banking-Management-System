# Modular Java Banking Management System (No Spring Boot)

## Files
- `src/BankServer.java` — starts the built-in Java HTTP server and routes web requests.
- `src/BankService.java` — account creation, deposits, withdrawals, and transaction history.
- `src/BankAccount.java` — account details, balance, deposit/withdraw rules.
- `src/Transaction.java` — stores a transaction record.
- `web/index.html` — browser interface.

## Requirements
- JDK 17 or newer
- VS Code (Java Extension Pack recommended)

## Run on Windows
Open this whole project folder in VS Code. In the terminal, run:

```powershell
javac -d out src\*.java
java -cp out BankServer
```

Open http://localhost:8080. Stop the server with Ctrl+C in the terminal.

This is an educational demo. Account and transaction data are stored in memory and reset when the server restarts. It supports one account and is not production banking software.
